#include "PID.h";
#include "vex.h";

// A global instance of competition
vex::competition Competition;

// The Brain
vex::brain Brain;

// The Four Drivetrain Motors
vex::motor LBDrive(vex::PORT13, vex::gearSetting::ratio18_1, true);
vex::motor RBDrive(vex::PORT1, vex::gearSetting::ratio18_1, false);
vex::motor LFDrive(vex::PORT8, vex::gearSetting::ratio18_1, true);
vex::motor RFDrive(vex::PORT20, vex::gearSetting::ratio18_1, false);

// The two intake motors located on the intake
vex::motor intakeMotor1(vex::PORT12, vex::gearSetting::ratio18_1, false);
vex::motor intakeMotor2(vex::PORT2, vex::gearSetting::ratio18_1, false);

// The motor that moves the arm
vex::motor armMotor(vex::PORT7, vex::gearSetting::ratio18_1, false);
vex::motor armMotorS(vex::PORT5, vex::gearSetting::ratio18_1, false);

// The motor assigned to the instant straighten hotkey
vex::motor heavyLiftingMotor(vex::PORT7, vex::gearSetting::ratio18_1, false);

// Teddy is a bad pc
vex::controller Controller = vex::controller();

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*---------------------------------------------------------------------------*/

void pre_auton(void) { armMotor.stop(brakeType::hold);armMotor.rotateFor(directionType::rev,200,rotationUnits::deg,50,velocityUnits::pct); }

/*---------------------------------------------------------------------------*/
/*                              Autonomous Task                              */
/*---------------------------------------------------------------------------*/
int ran = 0;
bool runIntakev = true;
bool outtake = false;

int setter() {
  while (true) {
    sensorValue1 = LBDrive.velocity(vex::velocityUnits::pct);
    sensorValue2 = RBDrive.velocity(vex::velocityUnits::pct);
    sensorValue3 = LFDrive.velocity(vex::velocityUnits::pct);
    sensorValue4 = RFDrive.velocity(vex::velocityUnits::pct);
  }
}

// The following functions take the amount the motor must rotate in degrees and
// the velocity it should rotate at in percentage of total capacity

int moveBackward(int rotation, int velocity) {

  LFDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RFDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  LBDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RBDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  return 0;
}

int moveForward(int rotation, int velocity) {

  LFDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RFDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  LBDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RBDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  return 0;
}
int rotateLeft(int rotation, int velocity) {

  LFDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RFDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  LBDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RBDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  return 0;
}

int rotateRight(int rotation, int velocity) {

  LFDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RFDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  LBDrive.rotateFor(vex::directionType::rev, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  RBDrive.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                    velocity, vex::velocityUnits::pct, false);
  return 0;
}

int runIntake() {
  while (true) {
    if (runIntakev == true) {
      intakeMotor1.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
      intakeMotor2.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
    } else {
      intakeMotor1.spin(vex::directionType::fwd, 0, vex::velocityUnits::pct);
      intakeMotor2.spin(vex::directionType::rev, 0, vex::velocityUnits::pct);
    }
  }
  return 0;
}

int runOuttake() {
  intakeMotor1.rotateFor(directionType::rev, 500, rotationUnits::deg, 40,
                         velocityUnits::pct);
  intakeMotor2.rotateFor(directionType::fwd, 500, rotationUnits::deg, 40,
                         velocityUnits::pct);
  return 0;
}

int runArm(int rotation, int velocity, bool isReversed, bool inversion) {
  armMotor.setReversed(isReversed);
  armMotor.rotateFor(vex::directionType::fwd, rotation, vex::rotationUnits::deg,
                     velocity, vex::velocityUnits::pct, false);
  return 0;
}

int beginningStraighten() { return 0; }

void autonomous(void) {
moveForward(200,40);
  task::sleep(400);
intakeMotor1.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
  intakeMotor2.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
  vex::task::sleep(1100);

  intakeMotor1.stop();
  intakeMotor2.stop();
  task::sleep(1000);
  moveBackward(150,30);
  task::sleep(400);
  armMotor.spin(vex::directionType::rev,50,vex::velocityUnits::pct);
  task::sleep(400);
  armMotor.stop();
  // Push a cube into the scoring zone
  vex::task intakeT(runIntake);
  runIntakev = true;

  // Get to the cubes
  moveForward(800, 40);
  task::sleep(2000);

  // Intake the cubes
  moveForward(450, 100);
  task::sleep(1000);

  // Face the goalpost

  moveBackward(700, 50);
  task::sleep(1000);
  rotateLeft(290, 50);
  task::sleep(600);
  moveForward(1000, 40);
  task::sleep(1500);
  rotateLeft(220, 40);
  task::sleep(600);
moveForward(345, 40);

  // Stop intak

  task::sleep(800);

  
  intakeT.stop();
  intakeMotor1.spin(vex::directionType::fwd, 0, vex::velocityUnits::pct);
  intakeMotor2.spin(vex::directionType::rev, 0, vex::velocityUnits::pct);

  vex::task outtakeT(runOuttake);

  // Stack

  runArm(1100, 40, false, true);
  task::sleep(2000);

  moveForward(100, 20);
  task::sleep(1000);

  // Get out
  moveBackward(500, 20);
  task::sleep(2000);




  // ..........................................................................

}

/*---------------------------------------------------------------------------*/
/*                              User Control Task                            */
/*---------------------------------------------------------------------------*/
/*
CONTROL SCHEME:

-----------------------------------------------------------------------
DRIVING- Sticks forward for forward, backward for backward, opposite directions
for turning.
-----------------------------------------------------------------------
INTAKE- R1 to intake, L1 to outtake
-----------------------------------------------------------------------
MAGAZINE- R2 up, L2 down, Up Arrow to autostack, Down Arrow to reset position
-----------------------------------------------------------------------
LIFT- NON-EXISTENT CURRENTLY!
-----------------------------------------------------------------------
MACROS- Button B to go straight back, Button A to go straight forward
-----------------------------------------------------------------------
*/

int toggleLift = 0;
int armSpd = 60;

int threshold = 10;
int yLeftStick;
int yRightStick;
int brakeTypeV = 1;
int brakeTypeManualV = 1;
int autoStacker = true;
float motorSpeed = 1.0f;
bool isDriveHotkey = false;

// Logic and computation for driving.
int drivetrains() {
  // Assigns a threshold for Left Stick Y so it doesn't drift
  if (abs(Controller.Axis3.position()) > threshold) {
    yLeftStick = Controller.Axis3.position();
  } else {
    yLeftStick = 0;
  }

  // assigns a threshold for Right Stick Y so it doesn't drift
  if (abs(Controller.Axis2.position()) > threshold) {
    yRightStick = Controller.Axis2.position();
  } else {
    yRightStick = 0;
  }

  // Computation for driving
  if (isDriveHotkey != true) {
    LFDrive.spin(directionType::rev, motorSpeed * yLeftStick,
                 velocityUnits::pct);
    RFDrive.spin(directionType::rev, motorSpeed * yRightStick,
                 velocityUnits::pct);
    LBDrive.spin(directionType::rev, motorSpeed * yLeftStick,
                 velocityUnits::pct);
    RBDrive.spin(directionType::rev, motorSpeed * yRightStick,
                 velocityUnits::pct);
  }

  return 0;
}

// Controls the movement of the two intake motors, the ones that push the cube
// up the ramp.
int intaking() {

  // If ButtonR1 is being pressed, the intakes will activate in CounterClockwise
  // motion
  if (Controller.ButtonR1.pressing()) {
    intakeMotor1.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
    intakeMotor2.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
  }

  // If ButtonL1 is being pressed, the intakes will activate in Clockwise motion
  else if (Controller.ButtonL1.pressing()) {
    intakeMotor1.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
    intakeMotor2.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
  }

  // If none of those conditions are true, the intakes will HALT
  else {
    intakeMotor1.spin(vex::directionType::rev, 0, vex::velocityUnits::pct);
    intakeMotor2.spin(vex::directionType::rev, 0, vex::velocityUnits::pct);
    intakeMotor1.stop(brakeType::hold);
    intakeMotor2.stop(brakeType::hold);
  }

  return (0);
}

// Controls the movement of the magazine
int magazine() {

  // If ButtonR2 is being pressed, and the position of the arm is not too high,
  // it will move up.
  if (Controller.ButtonR2.pressing()) {
    armMotor.spin(vex::directionType::fwd, 40, vex::velocityUnits::pct);
  }
  // If ButtonL2 is being pressed, and the position of the arm is not too low,
  // the arm will go down.
  else if (Controller.ButtonL2.pressing()) {
    autoStacker=1;
    armMotor.spin(vex::directionType::rev, 60, vex::velocityUnits::pct);
  }

  // If none of the conditions are met, then the arm will be stagnant.
  else if (Controller.ButtonUp.pressing() == false &&
           Controller.ButtonDown.pressing() == false) {
    armMotor.spin(vex::directionType::rev, 0, vex::velocityUnits::pct);
    armMotor.stop(vex::brakeType::hold);
  }

  return (0);
}

int autoStackerHotkey() {
  while (autoStacker == 2 && armMotor.rotation(rotationUnits::deg) < 11233&&Controller.ButtonL2.pressing()==false) {
    LFDrive.stop(brakeType::hold);
    LBDrive.stop(brakeType::hold);
    RFDrive.stop(brakeType::hold);
    RBDrive.stop(brakeType::hold);
    brakeTypeV = 2;
    armMotor.spin(vex::directionType::fwd, 40, vex::velocityUnits::pct);
    if (armMotor.rotation(rotationUnits::deg) >= 500 &&
        armMotor.rotation(rotationUnits::deg) <=850) {
      intakeMotor1.spin(vex::directionType::rev, 100, vex::velocityUnits::pct);
      intakeMotor2.spin(vex::directionType::fwd, 100, vex::velocityUnits::pct);
    }
  }
  if (brakeTypeV == 2) {
    LFDrive.stop(brakeType::coast);
    LBDrive.stop(brakeType::coast);
    RFDrive.stop(brakeType::coast);
    RBDrive.stop(brakeType::coast);
    brakeTypeV = 1;
  }

  return 0;
}

// moves two-bar to the three varying heights of towers (deprecated currently
// because lift is not present)
int moveToTower() {
  if (Controller.ButtonY.pressing()) {
    switch (toggleLift) {
    case 0:
      toggleLift++;
      heavyLiftingMotor.rotateTo(600, rotationUnits::deg, 80,
                                 velocityUnits::pct);
      armMotor.rotateTo(400, rotationUnits::deg, 80, velocityUnits::pct, false);
      break;
    case 1:
      toggleLift++;
      heavyLiftingMotor.rotateTo(1200, rotationUnits::deg, 80,
                                 velocityUnits::pct);
      armMotor.rotateTo(650, rotationUnits::deg, 80, velocityUnits::pct, false);
      break;

    case 2:
      toggleLift = 0;
      heavyLiftingMotor.rotateTo(0, rotationUnits::deg, 80, velocityUnits::pct);
      armMotor.rotateTo(0, rotationUnits::deg, 80, velocityUnits::pct, false);
      break;
    }
  }
  return 0;
}

// A hotkey task that lifts the arm automatically (since someone removed the
// arm, this is currently a deprecated function.)
/*
int straightenLift() {

  // If ButtonUp is pressed, the ramp will go to a maximum straight position.
  if (Controller.ButtonX.pressing()) {
    heavyLiftingMotor.spin(vex::directionType::rev, 30,
                           vex::velocityUnits::pct);
    // check the exact number. Ask thorstant for help if needed or tony
  }

  // If ButtonDown is pressed, the ramp will go to a minimum straight position.
  else if (Controller.ButtonA.pressing()) {
    heavyLiftingMotor.spin(vex::directionType::fwd, 30,
                           vex::velocityUnits::pct);
  } else {
    heavyLiftingMotor.stop(vex::brakeType::coast);
  }

  return 0;
}
*/
int goBackStraight() {
  if (Controller.ButtonB.pressing()) {
    isDriveHotkey = true;
    LFDrive.spin(vex::directionType::fwd, 25, vex::velocityUnits::pct);
    RFDrive.spin(vex::directionType::fwd, 25, vex::velocityUnits::pct);
    LBDrive.spin(vex::directionType::fwd, 25, vex::velocityUnits::pct);
    RBDrive.spin(vex::directionType::fwd, 25, vex::velocityUnits::pct);
    isDriveHotkey = false;
  }

  else if (Controller.ButtonA.pressing()) {
    isDriveHotkey = true;
    LFDrive.spin(vex::directionType::rev, 25, vex::velocityUnits::pct);
    RFDrive.spin(vex::directionType::rev, 25, vex::velocityUnits::pct);
    LBDrive.spin(vex::directionType::rev, 25, vex::velocityUnits::pct);
    RBDrive.spin(vex::directionType::rev, 25, vex::velocityUnits::pct);
    isDriveHotkey = false;
  }
  return 0;
}

void usercontrol(void) {

  while (true) {
    vex::task magazineT(magazine);
    vex::task intakingT(intaking);
    vex::task drivetrainT(drivetrains);
    vex::task moveToTowerT(moveToTower);
    vex::task goBackStraightT(goBackStraight);
    vex::task autoStackerHotkeyT(autoStackerHotkey);

    if (Controller.ButtonB.pressing() || Controller.ButtonA.pressing()) {
      goBackStraight();
    }

    if (Controller.ButtonRight.pressing()) {
      if (autoStacker == 1) {
        autoStacker = 2;
      } else {
        autoStacker = 1;
      }
    }
    if (Controller.ButtonX.pressing())
    {
      if (brakeTypeManualV==1)
      {
        LFDrive.stop(brakeType::hold);
        LBDrive.stop(brakeType::hold);
        RFDrive.stop(brakeType::hold);
        RBDrive.stop(brakeType::hold); 
        brakeTypeManualV=2;
      }
      else if(brakeTypeManualV==2)
      {
        LFDrive.stop(brakeType::coast);
        LBDrive.stop(brakeType::coast);
        RFDrive.stop(brakeType::coast);
        RBDrive.stop(brakeType::coast); 
        brakeTypeManualV=1;
      }
    }

    wait(20, msec);
  }
}

// Main will set up the competition functions and callbacks.

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
