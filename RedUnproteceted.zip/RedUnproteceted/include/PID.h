  /* 
   NOTE: The values for KP, KI, and KD are not final, and must be tested and refined for optimal performance.

   There are four variables of each thing because there are four motors that need the PID controller.

   In order to implement it, simply put the speed variables in place of the velocity for the motor movement class.
  
   Left-Back Drive: speed1
   Right-Back Drive: speed2
   Left-Front Drive: speed3
   Right-Front Drive: speed4

   These are the motors and the corresponding speed variables.

   Additionally, please set the target value and sensor value in a while loop inside the main code. An example is as follows.

void test ()
{
  while (true)
  {
  targetValue1 = LBDriveVelocity;
  targetValue2 = RBDriveVelocity;
  targetValue3 = LFDriveVelocity;
  targetValue4 = RFDriveVelocity;

  sensorValue1 = LBDrive.velocity (velocityUnits::pct);
  sensorValue2 = RBDrive.velocity (velocityUnits::pct);
  sensorValue3 = LFDrive.velocity (velocityUnits::pct);
  sensorValue4 = RFDrive.velocity (velocityUnits::pct);
  }
}
*/
//The four velocity variables are what you calculate for the velocity originally (the sum of the joystick values).

#include "vex.h"

//the target value
float targetValue;
//the value that is received by the sensor
float sensorValue1;
float sensorValue2;
float sensorValue3;
float sensorValue4;

//the integral
float integral1;
float integral2;
float integral3;
float integral4;

//the big three constants
double kp = 0.5;
double ki = 0.2;
double kd = 0.14;

//sets the speed
float speed1;
float speed2;
float speed3;
float speed4;


int calculation()
{
  while (true)
  {
    //error calculation
    float error1;
    float error2;
    float error3;
    float error4;
    
    //previous error value
    float previousError1;
    float previousError2;
    float previousError3;
    float previousError4;

    error1 = targetValue - sensorValue1;
    error2 = error1 - sensorValue2;
    error3 = error2 - sensorValue3;
    error4 =error3 - sensorValue4;
    
    //integral calculation
    integral1 += error1;
    integral2 += error2;
    integral3 += error3;
    integral4 += error4;
    
    //safety check
    if (error1 == 0 && error2 == 0 && error3 ==  0 && error4 == 0)
    {
      integral1 = 0;
      integral2 = 0;
      integral3 = 0;
      integral4 = 0;
    }
    
    //safety check
    if (error1 > 40 && error2 > 40 && error3 > 40 && error4 > 40)
    {
      integral1 = 0;
      integral2 = 0;
      integral3 = 0;
      integral4 = 0;
    }
    
    //derivative calculation
    float derivative1 = error1 - previousError1;
    float derivative2 = error2 - previousError2;
    float derivative3 = error3 - previousError3;
    float derivative4 = error4 - previousError4;
    
    //previous error calculation
     previousError1 = error1;
     previousError2 = error2;
     previousError3 = error3;
     previousError4 = error4;
          
    //final speed calculation
    speed1 = ((kp * error1) + (ki * integral1) + (kd * derivative1));
    speed2 = ((kp * error2) + (ki * integral2) + (kd * derivative2));
    speed3 = ((kp * error3) + (ki * integral3) + (kd * derivative3));
    speed4 = ((kp * error4) + (ki * integral4) + (kd * derivative4));
  }
}
